int service_listen_socket_multithread (const int s);
